$(document).ready(function(){
    //Parse.initialize("uzexoP2RQGMSARWVpi9VZsmp1Po7lGFHjzTsaXSZ", "K6qkNFSDvoE0h5biL7mmsPXuQwc083ESkdYZt1E7");
    $("#wrapper").load("firstrun.html");
});